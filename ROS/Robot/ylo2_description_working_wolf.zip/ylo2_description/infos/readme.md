Here are some informations about each xacro object, as mass, or inertia.
Objects have been simplified for less xacro memory/cpu usage.
On some objects, it material has been faked, to fit real mass, (t265, or d435 cameras, for example)
